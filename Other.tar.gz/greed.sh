#!/bin/bash
# Script to initialize database stuff

cd contrib/greed/ && make && make install
cd ../../ && make clean && make vmdex && make floppy && make boot-floppy