#include "../../sdk/dexsdk.h"

#define true 1
#define false 0

int **board;
int size, posX, posY, score = 0, row, col, temp, invalid = false;
char keypress;


typedef struct score
{
  char * name;
  int score;
  struct score * next;
}SCORE;

SCORE * highscores = NULL;
SCORE * tail = NULL;
char * name;
char nameL[10];

void getName(){
  int i = 0;
  textcolor(BROWN);
  printf("Enter Name (upto 10 only): ");
  textcolor(LIGHTGRAY);
  while(keypress != '\n' && i<10){
    keypress = getch();
    nameL[i] = keypress;
    printf("%c", keypress);
    i++;
  }
  nameL[i-1] = '\0';
  name = nameL;
}

void printBoard(){
  //print board
  clrscr();
  textcolor(BLUE);
  printf("\n-------------------------------------START-------------------------------------\n\n");
  printf("\tSCORE: %d\n",score);
  for (row = 0 ; row < size ; row++){
    printf("            ");
    for (col = 0 ; col < size ; col++){
      if (row == posY && col == posX) {
        textcolor(WHITE);
        printf("P ");
      }
      else if (board[row][col]==-1) printf("  ");
      else {
        textcolor(MAGENTA);
        printf("%d ",board[row][col]);
      }
    }//printing of controls
    textcolor(CYAN);
    if (row == 0) printf("\t\t\t\tControls");
    else if (row == 1) printf("\t\t\t\tW - Up");
    else if (row == 2) printf("\t\t\t\tA - Left");
    else if (row == 3) printf("\t\t\t\tD - Right");
    else if (row == 4) printf("\t\t\t\tX - Right");
    else if (row == 5) printf("\t\t\t\tQ - Top Left");
    else if (row == 6) printf("\t\t\t\tE - Top Right");
    else if (row == 7) printf("\t\t\t\tZ - Down Left");
    else if (row == 8) printf("\t\t\t\tC - Down Right");
    else if (row == 9) printf("\t\t\t\tO - Exit Game");
    printf("\n");
  }
  if (invalid) {
    textcolor(RED);
    printf("                BAD MOVE\n");
  }
}
void logo(){
  char greed[400] = "";
  int i = 0;
  int picker;
  clrscr();
  strcat(greed, "                          _____ _____ _____ _____ ____\n");
  strcat(greed, "                         |   __| __  |   __|   __|    \\\n");
  strcat(greed, "                         |  |  |    -|   __|   __|  |  |\n");
  strcat(greed, "                         |_____|__|__|_____|_____|____/\n");
  for(i=0;i<strlen(greed);i++){
    if(greed[i] == ' '){
      picker = 9;
    }
    else{
      picker = i%9;
    }
    if(picker==0) textcolor(CYAN);
    if(picker==1) textcolor(RED);
    if(picker==2) textcolor(LIGHTBLUE);
    if(picker==3) textcolor(LIGHTGREEN);
    if(picker==4) textcolor(LIGHTCYAN);
    if(picker==5) textcolor(LIGHTRED);
    if(picker==6) textcolor(LIGHTMAGENTA);
    if(picker==7) textcolor(YELLOW);
    if(picker==8) textcolor(MAGENTA);
    if(picker==9) textcolor(WHITE);
    printf("%c", greed[i]);
  }
}

void startingScreen(){
  logo();
  textcolor(BLUE);
  printf("\n--------------------------------------MENU--------------------------------------\n");
  printf("\n                                [1] Start Game");
  printf("\n                                [2] High Scores");
  printf("\n                                [3] Instructions");
  printf("\n                                [4] Exit\n");
  keypress = getch();
}

int validUp(){
  /* VALIDATION CHECKING */
  if (posY == 0) return false;
  //Check if out of range
  temp = board[posY-1][posX];
  if (temp == -1) return false;
  if (posY - temp < 0){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY-col][posX] == -1){
      return false;
    }
  }
  return true;
}

int validLeft(){
  /* VALIDATION CHECKKING */
  if (posX == 0) return false;
  //Check if out of range
  temp = board[posY][posX-1];
  if (temp == -1) return false;
  if (posX - temp< 0){
    return false;
  }
  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY][posX-col] == -1){
      return false;
    }
  }
  return true;
}

int validDown(){
  /* VALIDATION CHECKING */
  if (posY == size-1) return false;
  //Check if out of range
  temp = board[posY+1][posX];
  if (temp == -1) return false;
  if (posY + temp >= size){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY+col][posX] == -1){
      return false;
    }
  }
  return true;
}

int validRight(){
  /* VALIDATION CHECKING */
  if (posX == size-1) return false;
  //Check if out of range
  temp = board[posY][posX+1];
  if (temp == -1) return false;
  if (posX + temp >= size){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY][posX+col] == -1){
      return false;
    }
  }
  return true;
}

int validUpLeft(){
  /* VALIDATION CHECKING */
  if (posY == 0 || posX == 0) return false;
  //Check if out of range
  temp = board[posY-1][posX-1];
  if (temp == -1) return false;
  if (posY - temp < 0 || posX - temp < 0){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY-col][posX-col] == -1){
      return false;
    }
  }
  return true;
}

int validDownLeft(){
  /* VALIDATION CHECKING */
  if (posY == size-1 || posX == 0) return false;
  //Check if out of range
  temp = board[posY+1][posX-1];
  if (temp == -1) return false;
  if (posY + temp >= size || posX - temp < 0){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY+col][posX-col] == -1){
      return false;
    }
  }
  return true;
}

int validUpRight(){
  /* VALIDATION CHECKING */
  if (posY == 0 || posX == size-1) return false;
  //Check if out of range
  temp = board[posY-1][posX+1];
  if (temp == -1) return false;
  if (posY - temp < 0 || posX + temp >= size){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY-col][posX+col] == -1){
      return false;
    }
  }
  return true;
}

int validDownRight(){
  /* VALIDATION CHECKING */
  if (posY == size-1 || posX == size-1) return false;
  //Check if out of range
  temp = board[posY+1][posX+1];
  if (temp == -1) return false;
  if (posY + temp >= size || posX + temp >= size){
    return false;
  }

  //Check if none of the paths has already been taken
  for (col = 1 ; col <= temp ; col++){
    if (board[posY+col][posX+col] == -1){
      return false;
    }
  }
  return true;
}

void save_highscore(char * nametosave){
  SCORE * trav = highscores;
  SCORE * temp;
  temp = (SCORE *) malloc(sizeof(SCORE));
  temp->name = nametosave;
  temp->score = score;
  temp->next = NULL;
  // insert at head
  if(trav->score<=score){
    printf("NEW HIGHSCORE!\n");
    highscores = temp;
    temp->next = trav;
    return;
  }
  while(trav->next!=NULL){
    if(score >= trav->next->score){
      // insert at mid
      temp->next = trav->next;
      trav->next = temp;
      return;
    }
    else{
      trav = trav->next;
    }
  }
  // insert at tail
  tail->next = temp;
}

void my_reverse(char str[], int len)
{
    int start, end;
    char temp;
    for(start=0, end=len-1; start < end; start++, end--) {
        temp = *(str+start);
        *(str+start) = *(str+end);
        *(str+end) = temp;
    }
}

// Implementation of itoa()
char* my_itoa(int num, char* str, int base)
{
    int i = 0;
  int rem;
    /* Handle 0 explicitely, otherwise empty string is printed for 0 */
    if (num == 0)
    {
        str[i++] = '0';
        str[i] = '\0';
        return str;
    }

  str[i++] = '\0';

    // Process individual digits
    while (num != 0)
    {
        rem = num % base;
        str[i++] = rem+48;
        num = num/base;
    }

    // Reverse the string
    my_reverse(str, i);

    return str;
}

void save_highscore_file(){
  char msg[100] = "";
  char temp[100];
  FILE * file;
  SCORE * trav = highscores;
  SCORE * tempDel = NULL;
  file = fopen("hs.txt", "w");
  while(trav!=NULL){
    strcat(msg, trav->name);
    strcat(msg, " ");
    my_itoa(trav->score, temp, 10);
    strcat(msg, temp);
    strcat(msg, "\n");

    trav = trav->next;
  }
  fwrite(msg, 2*strlen(msg), 1, file);
  fclose(file);

  // free highscore linked list
  trav = highscores;
  tempDel = trav;
  while(trav!=NULL){
    trav = trav->next;
    free(tempDel);
    tempDel = trav;
  }
  free(highscores);

}

int myatoi(char *str){
  int res = 0;
  int i;
  for (i=0;str[i] != '\0';i++){
    res = res*10 + str[i] - '0';
  }

  return res;
}

void printHighscoreLL(SCORE * root){
  SCORE * trav = root;
  textcolor(DARKGRAY);
  while(trav!=NULL){
    printf("\t\tName: %s\n", trav->name);
    printf("\t\tScore: %d\n", trav->score);
    printf("\n");
    trav = trav->next;
  }
}

void load_highscores(){
  char *buf;
  char * line;
  FILE * file;
  int fsize;
  int i;

  file = fopen("hs.txt" ,"r");
  if (file != NULL){
    // put file contents in buf
    fseek(file, 0, SEEK_SET);
    fseek(file, 0, SEEK_END);
    fsize = ftell(file);
    fseek(file, 0, SEEK_SET);
    buf = (char *)  malloc(fsize);
    fread(buf, fsize, 1, file);

    // tokenize
    line = strtok(buf, " \n");
    i = 0;
    while(line != NULL){
      if(i%2==0){
          // if name
          if(highscores == NULL){
            // insert at head
            highscores = (SCORE *) malloc(sizeof(SCORE));
            highscores->name = line;
            highscores->next = NULL;
            tail = highscores;
          }
          else{
            tail->next = (SCORE *) malloc(sizeof(SCORE));
            tail->next->name = line;
            tail->next->next = NULL;
            tail = tail->next;
          }
      }
      else{
        // if score
        tail->score = myatoi(line);
      }
      // update
      line = strtok(NULL, " \n");
      i++;
    }
    fclose(file);
  }
}

void startgame(){
  int i,j;
  logo();
  score = 0;
  textcolor(BROWN);
  printf("WELCOME %s\n\n",name);
  textcolor(BLUE);
  printf("\n-------------------------------------LEVELS-------------------------------------\n");
  printf("\n                                  [1] 10 x 10");
  printf("\n                                  [2] 15 x 15");
  printf("\n                                  [3] 20 x 20\n");
  keypress = getch();

  if (keypress == '1') size = 10;
  else if(keypress == '2') size = 15;
  else if(keypress == '3') size = 20;
  else printf("Invalid input!");

  board = (int**) malloc(size * sizeof(int *));
  for (row = 0 ; row < size ; row++){
    board[row] = (int *) malloc(size * sizeof(int));
  }

   for (i=0;i<size;i++){
    for (j=0;j<size;j++){
      board[i][j] = rand()%9+1;
    }
   }

  posX = posY = size/2;

  //start game
  while(1){
    printBoard();
    invalid = false;
    if (!(validUp() || validDown() || validRight() || validLeft() || validUpRight() || validUpLeft() || validDownLeft() || validDownRight())){
      textcolor(RED);
      printf("No more available moves. Press any key to save your high score, %s.\n", name);
      getch();
      save_highscore(name);
      break;
    }
    keypress = toupper(getch());
    invalid = false;
    if (keypress == 'W'){
      if (validUp()) {
        for (row = 0 ; row < temp ; row++){
          board[posY][posX] = -1;
          posY--;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'D'){
      if (validRight()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posX++;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'X'){
      if (validDown()){
        for (row = 0 ; row < temp ; row++){
          board[posY][posX] = -1;
          posY++;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'A'){
      if (validLeft()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posX--;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'Q'){
      if (validUpLeft()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posY--;
          posX--;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'E'){
      if (validUpRight()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posY--;
          posX++;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'C'){
      if (validDownRight()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posY++;
          posX++;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'Z'){
      if (validDownLeft()){
        for (col = 0 ; col < temp ; col++){
          board[posY][posX] = -1;
          posY++;
          posX--;
        }
      }else{
        invalid = true;
      }
    }else if (keypress == 'O'){
      break;
    }else{
      invalid = true;
    }

    if (!invalid) score += temp;
  }
}

void highScores(){
  while(keypress != '1'){
    logo();
    textcolor(BLUE);
    printf("\n---------------------------------HIGH SCORES------------------------------------\n");
    printHighscoreLL(highscores);
    textcolor(BLUE);
    printf("[1] Go to Main Menu");
    keypress = getch();
  }
}

void instructions(){
  while(keypress != '1'){
    logo();
    textcolor(BLUE);
    printf("\n---------------------------------INSTRUCTIONS-----------------------------------\n");
    textcolor(DARKGRAY);
    printf("The player will choose a level that determines the size of the board.\n");
    printf("\t\tLevel 1 - 10 x 10\n");
    printf("\t\tLevel 2 - 15 x 15\n");
    printf("\t\tLevel 3 - 25 x 25\n");
    printf("The main goal of the game is to eat as many digits as possible.\n");
    printf("The player will start at the center of the board.\n");
    printf("The player will choose a direction.\n");
    printf("\t\tUp, Down, Left, Right\n");
    printf("\t\tUpper Left, Upper Right, Bottom Left, Bottom Right\n");
    printf("Number of steps = Number on the chosen direction.\n");
    printf("The player cannot go to the paths he has already taken.\n");
    printf("The score will be equal to the amount of steps taken.\n\n");
    textcolor(BLUE);
    printf("[1] Go to Main Menu");
    keypress = getch();
  }
}

int main(){
  char * nametemp;
  srand(time());
  load_highscores();

  getName();
  while (keypress!='4'){
    startingScreen();

    if (keypress == '1'){
      startgame();
    }
    else if (keypress == '2') highScores();
    else if (keypress == '3') instructions();
    else if (keypress == '4'){
      //exit
      for (row = 0 ; row < size ; row++){
        free(board[row]);
      }
      free(board);
      save_highscore_file();
    }
  }
}
